
Hi!

Thanks for downloading my little Anime-packed Icon-pack

Most of the icons here come from a picturs I have found on the
Internet. So far I have Ranma, Evangelion, Tenchi, You're Under 
Arrest-icons and Bubblegum Crisis, and I'm always looking for more :)


If you have any comments or anything please write me at ranma@algonet.se